<footer class="main-footer">
    <strong>Copyright &copy; 2020-2021 <a href="https://epac.com.bd/" target="_blank">Epac Limited</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.0.5
    </div>
</footer>
